package webApplicationsThotIt;
//01-29-2024, Monday
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/SignupServlet")

public class SignUpServlet extends HttpServlet {
	
	//private List<SignUpDTO> signuplist = new ArrayList<>();
	//noting in query parameter and everything else will go inside request body because of Post	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		String email = req.getParameter("email");
		String gender = req.getParameter("gender");
		
		SignUpDTO signupdto = new SignUpDTO(username, password, email, gender);
		try {
			//Step 1: Load the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver is loaded successfully.");
			
			//Step 2: Create the connection.
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/thothitweb_db","root","root");
			System.out.println("Connection has been created.");
			
			//step 3: Fire the query
			String insertquery = "insert into signup_tbl(username, password, email, gender) values(?, ?, ?, ?)";
			PreparedStatement pstatement = connection.prepareStatement(insertquery); //to execute the query
			
			//step 4: Set the value in placeholder
			pstatement.setString(1, username);
			pstatement.setString(2, password);
			pstatement.setString(3, email);
			pstatement.setString(4, gender);
			pstatement.executeUpdate();
			System.out.println("Inserted successfully.");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
//		signuplist.add(signupdto);
//		System.out.println(signuplist);
		
		req.setAttribute("email", "preeti@gmail.com");
		req.setAttribute("message", "data has been saved");
	//	req.setAttribute("sdata", signuplist);
		//req.getRequestDispatcher("slist.jsp").forward(req, resp);
		req.getRequestDispatcher("success.jsp").forward(req, resp);
	}

}
