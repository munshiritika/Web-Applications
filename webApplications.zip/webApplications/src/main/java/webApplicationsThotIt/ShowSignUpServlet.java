package webApplicationsThotIt;
//02-05-2024, Monday

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/signups")

public class ShowSignUpServlet extends HttpServlet{
//Will get data from Workbench
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//get the data and store in the list
		List<SignUpDTO> signupdtos= new ArrayList<SignUpDTO>();
		
		try {
			//step 1 load the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver is loaded successfully.");
			
			//step 2  create the connection
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/thothitweb_db","root","root");
			System.out.println("Connection has been created.");
			
			//step 3 fire the query
			String sql = "select id, username, password, email, gender from signup_tbl";
			PreparedStatement pStatement = conn.prepareStatement(sql);
			ResultSet resultSet = pStatement.executeQuery();
			
			while(resultSet.next()) {
				SignUpDTO signupdto = new SignUpDTO(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4), resultSet.getString(5));
				signupdtos.add(signupdto);
			}		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		req.setAttribute("message", "data has been retrieved");		
		req.setAttribute("sdata", signupdtos);
		req.getRequestDispatcher("slist.jsp").forward(req, resp);
	}

}

