package webApplicationsThotIt;
//02-08-2024, Thursday

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/esignup")

public class UpdateServlet extends HttpServlet {	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String sid = req.getParameter("id");
		String password = req.getParameter("password");
		String email = req.getParameter("email");
		String gender = req.getParameter("gender");
		System.out.println(gender + "------------------====================================================-");
		try {
			// 1.step load the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver is saved successfully.");
			
			// 2.create the connection
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/thothitweb_db","root","root");
			System.out.println("Connection has been created.");
			
			// 3.step fire the query
			String sql = "update signup_tbl set password=?, email=?, gender=? where id=?";
			PreparedStatement pStatement = connection.prepareStatement(sql);
			pStatement.setString(1, password);
			pStatement.setString(2, email);
			pStatement.setString(3, gender);
			pStatement.setInt(4, Integer.parseInt(sid));
			pStatement.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
		req.setAttribute("message", "Record has been updated.");
		req.getRequestDispatcher("signups").forward(req, resp);
	}

}
