package webApplicationsThotIt;
//02-07-2024, Wednesday

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/dsignup")

public class DeleteServlet extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String pid = req.getParameter("id"); //deleting based on id so we are requesting id
		
		List<SignUpDTO> signupdtos = new ArrayList<SignUpDTO>();
		try {
			//step 1 load the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver is loaded successfully.");
			
			//step 2  create the connection
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/thothitweb_db","root","root");
			System.out.println("Connection has been created.");
			
			//deleting record based on id
			String dquery = "delete from signup_tbl where id=?";	
			PreparedStatement pStatement = connection.prepareStatement(dquery);
			System.out.println(pid + "****");
			pStatement.setInt(1, Integer.parseInt(pid));  //index you want to delete, id in integer form
			pStatement.executeUpdate();
			
			//step 3 fire the query
			String sql = "select id, username, password, email, gender from signup_tbl";
			PreparedStatement pStatement1 = connection.prepareStatement(sql);
			ResultSet resultSet = pStatement1.executeQuery();
			
			//each time created object of SignUpDTO and add into SignUpDTO.
			while(resultSet.next()) {
				SignUpDTO signupdto = new SignUpDTO(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4), resultSet.getString(5));
				signupdtos.add(signupdto);
			}		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		req.setAttribute("message", "Data has been deleted and retrieved.");		
		req.setAttribute("sdata", signupdtos);
		req.getRequestDispatcher("slist.jsp").forward(req, resp);
	}
	
}

