package webApplicationsThotIt;
//01-30-2024, Tuesday

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/searchdata")

public class SearchServlet extends HttpServlet {
	private List<SignUpDTO> signuplist  = new ArrayList<SignUpDTO>();
	
	@Override
	public void init()  {
		  SignUpDTO dto1 = new SignUpDTO("susan","susan@123","susan@gmail.com","male");
	      SignUpDTO dto2 = new SignUpDTO("abdul","alex@123","alex@gmail.com","male");
	      SignUpDTO dto3 = new SignUpDTO("kavisha","kavish@123","kavish@gmail.com","female");
	      SignUpDTO dto4 = new SignUpDTO("ritika","ritika@123","ritika@gmail.com","female");
	      signuplist.add(dto1);
	      signuplist.add(dto2);
	      signuplist.add(dto3);
	      signuplist.add(dto4);
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String searchText = req.getParameter("searchText");
		// Creates a new list (searchResultList) to store search results.
		List<SignUpDTO> searchResultList = new ArrayList<SignUpDTO>();
		
		if (searchText == null || searchText.trim().length() == 0) {
			searchResultList = signuplist;
		}//if
		else {
			for (SignUpDTO signupdto : signuplist) {
				if (searchText.equals(signupdto.getUsername()) || searchText.equals(signupdto.getGender())
						|| searchText.equals(signupdto.getPassword()) || searchText.equals(signupdto.getEmail())) {
					searchResultList.add(signupdto);
				}//if
			}//for
		}//else
		
		if (searchResultList.size() == 0) {
			req.setAttribute("message", "no record found!!!");
		}//if
		req.setAttribute("kiki", searchResultList);
		req.getRequestDispatcher("search.jsp").forward(req, resp);
	}
  
}