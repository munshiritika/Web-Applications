package webApplicationsThotIt;
//01-26-2024, Friday
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/add")

public class AdditionClass extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int number1 = Integer.parseInt(req.getParameter("number1"));
		int number2 = Integer.parseInt(req.getParameter("number2"));
		
		int sum = number1 + number2;
		
		PrintWriter out = resp.getWriter();
		resp.getWriter().println("<html><body>");
		//This line writes an HTML heading level 2 (<h2>) to the response
		resp.getWriter().println("<h2> Result after addition</h2>");
		resp.getWriter().println("<p>" + number1+ "+ " + number2 +" = "+sum+"<p>");
		
	}
}
