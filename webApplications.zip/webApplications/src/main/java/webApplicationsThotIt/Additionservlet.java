package webApplicationsThotIt;
//01-29-2024, Monday
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/Additionservlet")

public class Additionservlet extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String a =req.getParameter("number1");
			String b =req.getParameter("number2");
		
			int num1=Integer.parseInt(a);
			int num2=Integer.parseInt(b);
			
			int sum=num1+num2;
			//This line writes the opening HTML and body tags to the response. It starts the HTML content that will be sent to the client's browser.
			resp.getWriter().println("<html><body>");
			//This line writes an HTML heading level 2 (<h2>) to the response
			resp.getWriter().println("<h2> Result after addition</h2>");
			resp.getWriter().println("<p>" + num1+ "+ " + num2 +" = "+sum+"<p>");
			
		}catch(NumberFormatException e) {
			resp.getWriter().println("</html></body>");
			resp.getWriter().println("<h2> Error:</h2>");
			resp.getWriter().println("<p> Please enter valid number</p>");
		}		
	}
	
}